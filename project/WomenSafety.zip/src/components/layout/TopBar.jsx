import React, { useRef } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { ShieldCheck, Bell, Home, Map, Siren, Users, Wrench, UserRound, Settings } from 'lucide-react';
import { useSafety } from '../../context/SafetyContext.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { Container } from './Container.jsx';
import { UserAvatar } from '../ui/UserAvatar.jsx';

export function TopBar() {
  const { safetyStatus, alerts, settings, triggerSecretSos } = useSafety();
  const { user } = useAuth();
  const unreadAlertsCount = alerts.filter((a) => !a.isRead).length;
  const tapCountRef = useRef(0);
  const tapTimerRef = useRef(null);

  const handleLogoTap = () => {
    tapCountRef.current += 1;
    if (tapTimerRef.current) clearTimeout(tapTimerRef.current);
    if (tapCountRef.current >= 3) {
      tapCountRef.current = 0;
      if (settings.secretSosEnabled) triggerSecretSos();
    } else {
      tapTimerRef.current = setTimeout(() => { tapCountRef.current = 0; }, 1200);
    }
  };

  const navLinks = [
    { label: 'Overview', path: '/', icon: Home },
    { label: 'Safety Map', path: '/map', icon: Map },
    { label: 'Emergency SOS', path: '/sos', icon: Siren, emergency: true },
    { label: 'Trusted Circle', path: '/contacts', icon: Users },
    { label: 'Safety Tools', path: '/tools', icon: Wrench },
    { label: 'Alerts', path: '/alerts', icon: Bell },
  ];

  return (
    <header className="women-topbar">
      <Container size="default">
        <div className="women-sidebar-inner">
          <div className="women-brand-row">
            <button type="button" onClick={handleLogoTap} className="women-logo" title="WomenSafety">
              <ShieldCheck className="w-5 h-5" />
            </button>
            <Link to="/" className="women-brand-copy">
              <span className="women-brand-name">WomenSafety</span>
              <span className="women-brand-sub">PERSONAL SAFETY PLATFORM</span>
            </Link>
          </div>

          <div className="women-status-pill">
            <span className={`women-status-dot ${safetyStatus === 'SOS Active' ? 'danger' : safetyStatus === 'Safety Setup Required' ? 'warning' : ''}`} />
            <div>
              <span className="women-status-title">{safetyStatus === 'SOS Active' ? 'Emergency active' : safetyStatus === 'Safety Setup Required' ? 'Setup required' : 'Protection active'}</span>
              <span className="women-status-caption">Your safety controls are ready</span>
            </div>
          </div>

          <nav className="women-sidebar-nav">
            <p className="women-nav-label">MAIN MENU</p>
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <NavLink key={link.path} to={link.path} className={({ isActive }) => `women-nav-link ${isActive ? 'active' : ''} ${link.emergency ? 'emergency-link' : ''}`}>
                  <Icon className="w-[18px] h-[18px]" />
                  <span>{link.label}</span>
                  {link.path === '/alerts' && unreadAlertsCount > 0 && <b>{unreadAlertsCount}</b>}
                </NavLink>
              );
            })}
            <p className="women-nav-label mt-5">ACCOUNT</p>
            <NavLink to="/profile" className={({ isActive }) => `women-nav-link ${isActive ? 'active' : ''}`}><UserRound className="w-[18px] h-[18px]" /><span>Profile</span></NavLink>
            <NavLink to="/settings" className={({ isActive }) => `women-nav-link ${isActive ? 'active' : ''}`}><Settings className="w-[18px] h-[18px]" /><span>Settings</span></NavLink>
          </nav>

          <div className="women-sidebar-footer">
            <div className="sidebar-sos-note"><Siren className="w-4 h-4" /><span><b>SOS is always one tap away</b><small>Use the Emergency Center for urgent help.</small></span></div>
            <Link to="/profile" className="women-user-mini">
              <UserAvatar name={user?.name} className="w-9 h-9 rounded-xl bg-[#f5e9ef] text-[#7b2949] font-bold text-xs" iconClassName="w-4 h-4 text-[#7b2949]" />
              <span><strong>{user?.name || 'My Account'}</strong><small>Safety profile</small></span>
            </Link>
          </div>
        </div>
      </Container>
    </header>
  );
}
