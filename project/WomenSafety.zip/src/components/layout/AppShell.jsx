import React from 'react';
import { TopBar } from './TopBar.jsx';
import { BottomNav } from './BottomNav.jsx';
import { EmergencyActiveModal } from '../emergency/EmergencyActiveModal.jsx';
import { FakeCallModal } from '../tools/FakeCallModal.jsx';
import { CheckInModal } from '../tools/CheckInModal.jsx';

export function AppShell({ children }) {
  return (
    <div className="women-app min-h-screen text-slate-900 flex flex-col font-sans antialiased">
      <TopBar />
      <main className="women-main flex-1 pb-24 pt-2">{children}</main>
      <BottomNav />
      <EmergencyActiveModal />
      <FakeCallModal />
      <CheckInModal />
    </div>
  );
}
