import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Home, Map, Users, Siren, Bell, Wrench } from 'lucide-react';
import { Container } from './Container.jsx';
import { useSafety } from '../../context/SafetyContext.jsx';

export function BottomNav() {
  const location = useLocation();
  const { alerts } = useSafety();
  const unreadAlerts = alerts.filter((a) => !a.isRead).length;
  const items = [
    { label: 'Home', path: '/', icon: Home },
    { label: 'Map', path: '/map', icon: Map },
    { label: 'SOS', path: '/sos', icon: Siren, sos: true },
    { label: 'Circle', path: '/contacts', icon: Users },
    { label: 'Tools', path: '/tools', icon: Wrench },
    { label: 'Alerts', path: '/alerts', icon: Bell, badge: unreadAlerts },
  ];
  return (
    <nav className="women-bottom-nav md:hidden">
      <Container size="default">
        <div className="women-bottom-inner">
          {items.map((item) => {
            const Icon = item.icon;
            const active = location.pathname === item.path;
            return <NavLink key={item.path} to={item.path} className={`women-bottom-item ${active ? 'active' : ''} ${item.sos ? 'sos' : ''}`}>
              <span className="women-bottom-icon"><Icon className="w-4 h-4" />{item.badge > 0 && <i />}</span><small>{item.label}</small>
            </NavLink>;
          })}
        </div>
      </Container>
    </nav>
  );
}
