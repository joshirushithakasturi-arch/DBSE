import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import {
  Crosshair,
  Navigation,
  Shield,
  Radio,
  Clock,
  Layers,
  MapPin
} from 'lucide-react';
import { Button } from '../ui/Button.jsx';
import { Badge } from '../ui/Badge.jsx';
import { useSafety } from '../../context/SafetyContext.jsx';

// Custom CSS for Leaflet marker pulse
const pulseIconHtml = `
  <div style="position: relative; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center;">
    <div style="position: absolute; width: 24px; height: 24px; border-radius: 50%; background: rgba(14, 165, 233, 0.4); animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
    <div style="width: 14px; height: 14px; border-radius: 50%; background: #0284c7; border: 2.5px solid #ffffff; box-shadow: 0 1px 4px rgba(0,0,0,0.3);"></div>
  </div>
`;

export function DeviceMap({
  onSelectCoordinates,
  selectedCoordinates,
  safePlaces = [],
  selectedPlace = null,
  onSelectPlace,
  onRecenter,
}) {
  const {
    location,
    lastKnownLocation,
    requestLocation,
    safetyZones,
    currentSafetyZone,
  } = useSafety();

  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const userMarkerRef = useRef(null);
  const accuracyCircleRef = useRef(null);
  const zonesLayerRef = useRef(null);
  const placesLayerRef = useRef(null);

  const hasRealCoords = location.latitude !== null && location.longitude !== null;

  // Initialize the map even before GPS is available. This guarantees the map UI is always visible.
  // Once the user presses "Use my current location" and the browser grants permission,
  // the map flies to the real device position.
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const defaultCenter = [20.5937, 78.9629];
    const map = L.map(mapContainerRef.current, {
      center: hasRealCoords ? [location.latitude, location.longitude] : defaultCenter,
      zoom: hasRealCoords ? 15 : 5,
      zoomControl: false,
    });

    L.control.zoom({ position: 'bottomright' }).addTo(map);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    zonesLayerRef.current = L.featureGroup().addTo(map);
    placesLayerRef.current = L.featureGroup().addTo(map);

    map.on('click', (e) => {
      if (onSelectCoordinates) {
        onSelectCoordinates({ latitude: e.latlng.lat, longitude: e.latlng.lng });
      }
    });

    mapInstanceRef.current = map;

    const timer = setTimeout(() => map.invalidateSize(), 150);
    return () => clearTimeout(timer);
  }, []);

  // Keep the map centered on the real device location whenever a fresh GPS fix arrives.
  useEffect(() => {
    if (!mapInstanceRef.current || !hasRealCoords) return;

    const map = mapInstanceRef.current;
    const lat = location.latitude;
    const lng = location.longitude;
    const accuracy = location.accuracy || 20;

    if (!userMarkerRef.current) {
      const pulseIcon = L.divIcon({
        html: pulseIconHtml,
        className: 'user-location-pulse-marker',
        iconSize: [24, 24],
        iconAnchor: [12, 12],
      });
      userMarkerRef.current = L.marker([lat, lng], { icon: pulseIcon }).addTo(map);
      userMarkerRef.current.bindPopup(`
        <div style="font-family: inherit; font-size: 12px; padding: 2px;">
          <strong>Your current device position</strong><br/>
          <span>Accuracy: ±${accuracy} m</span><br/>
          <span style="font-family: monospace; font-size: 11px;">${lat.toFixed(5)}, ${lng.toFixed(5)}</span>
        </div>
      `);
    } else {
      userMarkerRef.current.setLatLng([lat, lng]);
    }

    if (!accuracyCircleRef.current) {
      accuracyCircleRef.current = L.circle([lat, lng], {
        radius: accuracy,
        color: '#0284c7',
        weight: 1.5,
        fillColor: '#38bdf8',
        fillOpacity: 0.15,
      }).addTo(map);
    } else {
      accuracyCircleRef.current.setLatLng([lat, lng]);
      accuracyCircleRef.current.setRadius(accuracy);
    }

    if (!map._womenSafetyHasCentered) {
      map.flyTo([lat, lng], 16, { duration: 0.9 });
      map._womenSafetyHasCentered = true;
    }

    if (zonesLayerRef.current) {
      zonesLayerRef.current.clearLayers();
      safetyZones.forEach((zone) => {
        if (zone.latitude != null && zone.longitude != null) {
          const zoneCircle = L.circle([zone.latitude, zone.longitude], {
            radius: zone.radiusMeters || 200,
            color: '#059669',
            weight: 2,
            dashArray: '5, 5',
            fillColor: '#10b981',
            fillOpacity: 0.15,
          });
          zoneCircle.bindPopup(`
            <div style="font-family: inherit; font-size: 12px;">
              <strong>Safety Zone: ${zone.name}</strong><br/>
              <span>Geofence radius: ${zone.radiusMeters}m</span>
            </div>
          `);
          zonesLayerRef.current.addLayer(zoneCircle);
        }
      });
    }

    const timer = setTimeout(() => map.invalidateSize(), 100);
    return () => clearTimeout(timer);
  }, [hasRealCoords, location.latitude, location.longitude, location.accuracy, safetyZones]);

  // Render real nearby safe places markers
  useEffect(() => {
    if (!placesLayerRef.current || !mapInstanceRef.current) return;
    placesLayerRef.current.clearLayers();

    safePlaces.forEach((place) => {
      if (place.latitude && place.longitude) {
        let bgColor = '#0284c7';
        let symbol = '🛡️';
        if (place.type === 'Police') {
          bgColor = '#1d4ed8';
          symbol = '👮';
        } else if (place.type === 'Hospital') {
          bgColor = '#e11d48';
          symbol = '🏥';
        } else if (place.type === 'Pharmacy') {
          bgColor = '#059669';
          symbol = '💊';
        } else if (place.type === 'Shelter') {
          bgColor = '#7c3aed';
          symbol = '🌸';
        }

        const iconHtml = `
          <div style="
            background-color: ${bgColor};
            color: white;
            width: 26px;
            height: 26px;
            border-radius: 50% 50% 50% 0;
            transform: rotate(-45deg);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
            border: 2px solid #ffffff;
            cursor: pointer;
          ">
            <div style="transform: rotate(45deg); font-size: 12px; line-height: 1;">
              ${symbol}
            </div>
          </div>
        `;

        const placeIcon = L.divIcon({
          html: iconHtml,
          className: 'safe-place-pin-marker',
          iconSize: [26, 26],
          iconAnchor: [13, 26],
          popupAnchor: [0, -26],
        });

        const marker = L.marker([place.latitude, place.longitude], {
          icon: placeIcon,
        });

        const popupContent = `
          <div style="font-family: inherit; font-size: 12px; min-width: 170px; max-width: 230px; padding: 2px;">
            <div style="font-weight: 700; color: #0f172a; font-size: 13px; line-height: 1.3; margin-bottom: 3px;">
              ${place.name}
            </div>
            <div style="display: flex; gap: 4px; align-items: center; margin-bottom: 4px; flex-wrap: wrap;">
              <span style="background-color: #f1f5f9; color: #334155; font-size: 10px; font-weight: 600; padding: 2px 6px; border-radius: 4px;">
                ${place.category || place.type}
              </span>
              <span style="font-size: 11px; font-weight: 700; color: #0284c7;">
                ${place.distanceText || ''}
              </span>
            </div>
            <div style="font-size: 11px; color: #64748b; line-height: 1.3; margin-bottom: 4px;">
              ${place.address || 'Address not listed'}
            </div>
            ${place.isOpen !== null && place.isOpen !== undefined ? `
              <div style="font-size: 10px; font-weight: 600; color: ${place.isOpen ? '#059669' : '#dc2626'}; margin-bottom: 4px;">
                ${place.isOpen ? '● Open Now' : '● Currently Closed'}
              </div>
            ` : ''}
            ${place.rating ? `
              <div style="font-size: 11px; color: #d97706; font-weight: 600;">
                ★ ${place.rating} ${place.userRatingsTotal ? `<span style="color: #94a3b8; font-weight: normal;">(${place.userRatingsTotal})</span>` : ''}
              </div>
            ` : ''}
          </div>
        `;

        marker.bindPopup(popupContent);

        if (onSelectPlace) {
          marker.on('click', () => onSelectPlace(place));
        }

        placesLayerRef.current.addLayer(marker);
      }
    });
  }, [safePlaces, onSelectPlace]);

  // Fly to selected place if requested
  useEffect(() => {
    if (mapInstanceRef.current && selectedPlace?.latitude && selectedPlace?.longitude) {
      mapInstanceRef.current.flyTo([selectedPlace.latitude, selectedPlace.longitude], 17, {
        duration: 0.8,
      });
    }
  }, [selectedPlace]);

  // Clean up Leaflet on unmount
  useEffect(() => {
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  const handleRecenter = () => {
    if (mapInstanceRef.current && hasRealCoords) {
      mapInstanceRef.current.flyTo([location.latitude, location.longitude], 16, {
        duration: 1,
      });
    } else {
      requestLocation();
    }
    if (onRecenter) {
      onRecenter();
    }
  };

  // Map is always rendered. If GPS is unavailable, the user can explicitly request the current location.
  // 2. REAL DEVICE MAP DISPLAY
  return (
    <div className="relative w-full h-72 sm:h-80 rounded-2xl overflow-hidden border border-slate-200 shadow-xs bg-slate-100">
      {/* Real Leaflet Map Container */}
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {!hasRealCoords && (
        <div className="absolute inset-0 z-20 bg-slate-950/45 backdrop-blur-[1px] flex items-center justify-center p-5">
          <div className="w-full max-w-sm rounded-2xl bg-white/95 border border-white shadow-2xl p-5 text-center">
            <div className="mx-auto mb-3 w-11 h-11 rounded-2xl bg-slate-900 text-white grid place-items-center">
              <Navigation className="w-5 h-5" />
            </div>
            <div className="text-[10px] uppercase tracking-[0.16em] font-black text-slate-500">WomenSafety location</div>
            <h3 className="mt-1 text-base font-black text-slate-900">{location.permission === 'denied' ? 'Location access is blocked' : 'Use your current location'}</h3>
            <p className="mt-1.5 text-xs leading-relaxed text-slate-500">
              {location.permission === 'denied'
                ? 'Allow location for this website in your browser site settings, then press the button again.'
                : 'Press the button below to request your device location. The map will automatically center on the returned coordinates.'}
            </p>
            <button
              type="button"
              onClick={requestLocation}
              className="mt-4 inline-flex items-center justify-center gap-2 rounded-xl bg-slate-950 px-4 py-2.5 text-xs font-extrabold text-white hover:bg-slate-800 transition-colors"
            >
              <Crosshair className="w-4 h-4" />
              {location.permission === 'denied' ? 'Try Location Again' : 'Use My Current Location'}
            </button>
          </div>
        </div>
      )}

      {/* Top Overlays */}
      <div className="absolute top-3 left-3 z-10 flex flex-wrap gap-2 pointer-events-none">
        {/* Real-time Tracking Badge */}
        <div className="bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-lg border border-slate-200 text-[11px] font-bold text-slate-800 shadow-xs flex items-center gap-1.5 pointer-events-auto">
          <span className="flex h-2 w-2 relative">
            {location.isTracking && (
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            )}
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
          <span>{location.isTracking ? 'Live Tracking' : hasRealCoords ? 'GPS Connected' : 'Location Not Set'}</span>
          {hasRealCoords && <span className="text-slate-400 font-normal font-mono">±{location.accuracy || 12}m</span>}
        </div>

        {/* Current Safety Zone Status */}
        <div className="bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-700 shadow-xs flex items-center gap-1.5 pointer-events-auto">
          <Shield className="w-3.5 h-3.5 text-emerald-600" />
          <span>Zone: {currentSafetyZone.name || 'Outside Geofence'}</span>
        </div>
      </div>

      {/* Bottom Floating Controls */}
      <div className="absolute bottom-3 left-3 z-10 flex items-center gap-2">
        <div className="bg-white/90 backdrop-blur-xs px-2 py-1 rounded-lg border border-slate-200 text-[10px] text-slate-600 font-mono shadow-xs">
          {hasRealCoords ? `${location.latitude.toFixed(5)}, ${location.longitude.toFixed(5)}` : 'Waiting for current location'}
        </div>
      </div>

      <div className="absolute bottom-3 right-14 z-10">
        <button
          type="button"
          onClick={handleRecenter}
          title="Use your current device location"
          className="bg-white/95 backdrop-blur-xs px-2.5 py-1.5 rounded-xl border border-slate-200 shadow-sm text-slate-700 hover:text-slate-950 flex items-center gap-1 text-xs font-bold transition-all cursor-pointer hover:bg-slate-50"
        >
          <Crosshair className="w-3.5 h-3.5 text-blue-600" />
          <span>{hasRealCoords ? 'My Location' : 'Use My Location'}</span>
        </button>
      </div>
    </div>
  );
}
