import React, { useEffect, useRef, useState } from 'react';
import { ShieldAlert, Fingerprint } from 'lucide-react';

export function SosHoldButton({ onActivate }) {
  const [holding, setHolding] = useState(false);
  const [progress, setProgress] = useState(0);
  const timerRef = useRef(null);
  const rafRef = useRef(null);
  const startRef = useRef(0);
  const triggeredRef = useRef(false);
  const HOLD_MS = 1500;

  const stop = () => {
    setHolding(false);
    if (timerRef.current) clearTimeout(timerRef.current);
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    if (!triggeredRef.current) setProgress(0);
    triggeredRef.current = false;
  };

  const tick = () => {
    const elapsed = Date.now() - startRef.current;
    const next = Math.min(100, (elapsed / HOLD_MS) * 100);
    setProgress(next);
    if (next < 100) rafRef.current = requestAnimationFrame(tick);
  };

  const start = (e) => {
    e.preventDefault();
    setHolding(true);
    triggeredRef.current = false;
    startRef.current = Date.now();
    rafRef.current = requestAnimationFrame(tick);
    timerRef.current = setTimeout(() => {
      triggeredRef.current = true;
      setProgress(100);
      onActivate?.();
    }, HOLD_MS);
  };

  useEffect(() => () => stop(), []);

  return (
    <div className="sos-control-wrap">
      <div className="sos-control-head"><span><Fingerprint size={15} /> Verified emergency control</span><em>HOLD 1.5 SEC</em></div>
      <button
        type="button"
        className={`sos-command-button ${holding ? 'is-holding' : ''}`}
        onMouseDown={start}
        onMouseUp={stop}
        onMouseLeave={stop}
        onTouchStart={start}
        onTouchEnd={stop}
        onTouchCancel={stop}
        onContextMenu={(e) => e.preventDefault()}
      >
        <span className="sos-command-progress" style={{ width: `${progress}%` }} />
        <span className="sos-command-content">
          <span className="sos-command-icon"><ShieldAlert size={27} /></span>
          <span className="sos-command-copy"><strong>ACTIVATE SOS</strong><small>{holding ? 'Keep holding…' : 'Hold to alert your trusted circle'}</small></span>
          <span className="sos-command-arrow">→</span>
        </span>
      </button>
      <p className="sos-command-help">Your location and emergency response flow are prepared before the alert is sent.</p>
    </div>
  );
}
