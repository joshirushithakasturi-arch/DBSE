import React from 'react';
import { Link } from 'react-router-dom';
import { PhoneCall, Clock3, MapPin, Users, ShieldCheck, Wrench, Navigation, Bell, ArrowUpRight } from 'lucide-react';
import { Container } from '../components/layout/Container.jsx';
import { Card } from '../components/ui/Card.jsx';
import { SosHoldButton } from '../components/emergency/SosHoldButton.jsx';
import { LocationStatusCard } from '../components/location/LocationStatusCard.jsx';
import { useSafety } from '../context/SafetyContext.jsx';

export function HomePage() {
  const { safetyStatus, contacts, safetyZones, currentSafetyZone, checkIn, location, isOnline, sosLogs, settings, setFakeCallOpen, setCheckInModalOpen, toggleLocationSharing } = useSafety();
  const latestSos = sosLogs[0] || null;
  const safe = safetyStatus !== 'SOS Active';
  const locationLabel = location.permission === 'denied' ? 'Unavailable' : location.latitude ? (location.isSharing ? 'Live sharing' : 'Connected') : 'Needs permission';
  const zoneLabel = safetyZones.length === 0 ? 'Not configured' : currentSafetyZone.inside ? `${currentSafetyZone.name} • Inside` : 'Outside safe zones';

  return (
    <div className="py-5 sm:py-7">
      <Container size="default">
        <section className="ws-hero">
          <div className="ws-hero-grid">
            <div>
              <div className="ws-kicker">WOMENSAFETY • PRIVATE SAFETY SPACE</div>
              <h1>{safe ? 'You are in control.' : 'Emergency response is active.'}</h1>
              <p>{safe ? 'One place for emergency help, trusted contacts, location sharing and practical safety tools. Your essential controls stay close and simple.' : 'Follow the emergency flow below and keep your trusted circle informed.'}</p>
            </div>
            <div className="ws-live">
              <div className="ws-live-title">Protection status</div>
              <div className="ws-live-value"><span className={`ws-live-dot ${!safe ? 'bg-rose-400' : ''}`} />{safe ? 'Protection active' : 'Emergency active'}</div>
              <div className="text-[10px] text-[#d9b7c5] mt-2">{contacts.length} trusted contact{contacts.length === 1 ? '' : 's'} configured</div>
            </div>
          </div>
        </section>

        <div className="ws-section-label">EMERGENCY CONTROL</div>
        <section className="grid lg:grid-cols-[1.25fr_.75fr] gap-3">
          <Card className="p-5 sm:p-7 bg-white border-[#eadfe4] text-center">
            <div className="mb-4"><span className="text-[9px] font-black uppercase tracking-[.16em] text-[#9b8d94]">Primary emergency action</span></div>
            <SosHoldButton />
          </Card>
          <div className="ws-command-card sos justify-between">
            <div><div className="ws-command-icon"><ShieldCheck className="w-5 h-5" /></div><div className="ws-command-title mt-5">Emergency SOS</div><div className="ws-command-sub">Hold the SOS control to begin your emergency response.</div></div>
            <Link to="/sos" className="ws-command-action flex items-center gap-1">Open emergency center <ArrowUpRight className="w-3 h-3" /></Link>
          </div>
        </section>

        <div className="ws-section-label">QUICK ACTIONS</div>
        <section className="ws-command-grid">
          <button type="button" onClick={() => setFakeCallOpen(true)} className="ws-command-card text-left cursor-pointer"><div><div className="ws-command-icon"><PhoneCall className="w-4 h-4" /></div><div className="ws-command-title mt-3">Fake Call</div><div className="ws-command-sub">Create a discreet exit.</div></div><span className="ws-command-action">Start tool</span></button>
          <button type="button" onClick={() => setCheckInModalOpen(true)} className="ws-command-card text-left cursor-pointer"><div><div className="ws-command-icon"><Clock3 className="w-4 h-4" /></div><div className="ws-command-title mt-3">Safety Check-In</div><div className="ws-command-sub">{checkIn.isActive ? 'Timer active' : 'Set a timer'}</div></div><span className="ws-command-action">Open</span></button>
          <Link to="/map?tab=places" className="ws-command-card"><div><div className="ws-command-icon"><Navigation className="w-4 h-4" /></div><div className="ws-command-title mt-3">Safe Places</div><div className="ws-command-sub">Find nearby support.</div></div><span className="ws-command-action">View map</span></Link>
          <Link to="/contacts" className="ws-command-card"><div><div className="ws-command-icon"><Users className="w-4 h-4" /></div><div className="ws-command-title mt-3">Trusted Circle</div><div className="ws-command-sub">{contacts.length} of 7 contacts ready.</div></div><span className="ws-command-action">Manage</span></Link>
        </section>

        <div className="ws-section-label">SAFETY OVERVIEW</div>
        <section className="ws-status-grid">
          <Link to="/map" className="ws-status-card"><div className="ws-status-top"><span className="ws-status-name">Location</span><MapPin className="w-4 h-4 text-[#b23a67]" /></div><div className="ws-status-value"><span className="ws-mini-dot" />{locationLabel}</div></Link>
          <Link to="/map?tab=zones" className="ws-status-card"><div className="ws-status-top"><span className="ws-status-name">Safe Zone</span><ShieldCheck className="w-4 h-4 text-[#b23a67]" /></div><div className="ws-status-value">{zoneLabel}</div></Link>
          <button type="button" onClick={() => setCheckInModalOpen(true)} className="ws-status-card text-left"><div className="ws-status-top"><span className="ws-status-name">Check-In</span><Clock3 className="w-4 h-4 text-[#b23a67]" /></div><div className="ws-status-value"><span className={`ws-mini-dot ${checkIn.status === 'missed' ? 'warn' : ''}`} />{checkIn.status === 'missed' ? 'Missed alert' : checkIn.isActive ? 'Active' : 'Inactive'}</div></button>
          <Link to="/alerts" className="ws-status-card"><div className="ws-status-top"><span className="ws-status-name">Alerts</span><Bell className="w-4 h-4 text-[#b23a67]" /></div><div className="ws-status-value">{latestSos ? `${latestSos.type} recorded` : 'No recent SOS'}</div></Link>
        </section>

        <div className="ws-section-label">CONNECTION & LOCATION</div>
        <div className="ws-location-panel"><LocationStatusCard showTrackingControls={true} /></div>
        <Card className="mt-3 p-4 bg-white border-[#eadfe4]">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-[#faf5f7]"><span className="text-[#978a91] block text-[9px] uppercase font-extrabold tracking-wider">Network</span><b className="block mt-1 text-[#33242c]"><span className={`ws-mini-dot ${isOnline ? '' : 'warn'}`} />{isOnline ? 'Connected' : 'Offline'}</b></div>
            <div className="p-3 rounded-xl bg-[#faf5f7]"><span className="text-[#978a91] block text-[9px] uppercase font-extrabold tracking-wider">Safety network</span><b className="block mt-1 text-[#33242c]">{settings.safetyNetworkEnabled ? 'Available' : 'Off'}</b></div>
            <div className="p-3 rounded-xl bg-[#faf5f7]"><span className="text-[#978a91] block text-[9px] uppercase font-extrabold tracking-wider">Location sharing</span><button onClick={toggleLocationSharing} className="font-black text-[#9b2f54] mt-1">{location.isSharing ? 'On • tap to stop' : 'Off • tap to share'}</button></div>
          </div>
        </Card>

        <div className="mt-5 flex items-center justify-between rounded-2xl border border-[#eadfe4] bg-white p-4">
          <div className="flex items-center gap-3"><div className="w-9 h-9 rounded-xl bg-[#f7e8ee] text-[#9b2f54] grid place-items-center"><Wrench className="w-4 h-4" /></div><div><b className="text-xs">Need another safety tool?</b><p className="text-[10px] text-[#95878f] mt-0.5">Access only the essential tools from one focused workspace.</p></div></div>
          <Link to="/tools" className="text-[10px] font-black uppercase tracking-wider text-[#9b2f54]">Open tools →</Link>
        </div>
      </Container>
    </div>
  );
}
