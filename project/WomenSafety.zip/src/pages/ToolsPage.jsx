import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowUpRight,
  Check,
  ClipboardCopy,
  FileCheck2,
  FileText,
  Gauge,
  LifeBuoy,
  Lock,
  Unlock,
  MapPin,
  MessageSquareText,
  PhoneCall,
  ShieldAlert,
  Signal,
  Sparkles,
  RefreshCw,
  Trash2,
  X,
} from 'lucide-react';
import { Container } from '../components/layout/Container.jsx';
import { useSafety } from '../context/SafetyContext.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { EmergencyCardService, IntegrityService } from '../services/api.js';

async function copyText(text) {
  // Modern clipboard API.
  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (_) {}
  }

  // Reliable fallback for desktop browsers and non-secure preview environments.
  try {
    const area = document.createElement('textarea');
    area.value = text;
    area.setAttribute('readonly', '');
    area.style.position = 'fixed';
    area.style.left = '-9999px';
    area.style.top = '0';
    document.body.appendChild(area);
    area.focus();
    area.select();
    const ok = document.execCommand('copy');
    area.remove();
    return ok;
  } catch (_) {
    return false;
  }
}

function buildEmergencyMessage(situation, includeLocation, location) {
  let text = situation.trim() || 'I need help. Please contact me as soon as possible.';
  if (includeLocation && location?.latitude != null && location?.longitude != null) {
    text += `\nMy current coordinates: ${Number(location.latitude).toFixed(6)}, ${Number(location.longitude).toFixed(6)}`;
    text += `\nMap: https://www.google.com/maps?q=${location.latitude},${location.longitude}`;
  }
  return text;
}

function ToolModal({ title, eyebrow, icon: Icon, children, onClose }) {
  return (
    <div className="ws-tool-modal-backdrop" onClick={onClose}>
      <div className="ws-tool-modal" onClick={(e) => e.stopPropagation()}>
        <div className="ws-tool-modal-head">
          <div className="ws-tool-modal-title">
            <span><Icon size={18} /></span>
            <div><small>{eyebrow}</small><h3>{title}</h3></div>
          </div>
          <button type="button" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function CommunityEmergencyFeed({ onResolve }) {
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('');

  const load = async () => {
    try {
      const next = await EmergencyCardService.getFeed();
      setCards(next);
      setStatus('');
    } catch (err) {
      setStatus(err?.message || 'The shared emergency network is temporarily unavailable.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const timer = window.setInterval(load, 10000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <div className="ws-community-feed">
      <div className="ws-community-head">
        <div>
          <small>WOMENSAFETY NETWORK</small>
          <strong>Live emergency cards</strong>
          <span>Active cards from registered WomenSafety users appear here automatically.</span>
        </div>
        <button type="button" className="ws-icon-btn" onClick={load} aria-label="Refresh emergency cards"><RefreshCw size={16} /></button>
      </div>
      {loading && <div className="ws-community-empty">Connecting to the safety network…</div>}
      {!loading && !cards.length && <div className="ws-community-empty"><ShieldAlert size={18} />No active emergency cards right now.</div>}
      {status && <div className="ws-tool-status-error">{status}</div>}
      <div className="ws-community-list">
        {cards.map((card) => (
          <article key={card.id} className={`ws-emergency-card ${card.is_mine ? 'mine' : ''}`}>
            <div className="ws-emergency-card-top">
              <div className="ws-emergency-card-avatar"><ShieldAlert size={18} /></div>
              <div><b>{card.is_mine ? 'Your emergency card' : card.name}</b><small>{card.is_mine ? 'Broadcasting to WomenSafety users' : 'WomenSafety emergency broadcast'}</small></div>
              <span className="ws-emergency-live"><i />LIVE</span>
            </div>
            <p>{card.message}</p>
            <div className="ws-emergency-meta">
              {card.location_included && <span><MapPin size={13} /> Location attached</span>}
              <span>Expires {new Date(card.expires_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
            {card.location_included && card.latitude != null && card.longitude != null && (
              <a className="ws-emergency-map" href={`https://www.google.com/maps?q=${card.latitude},${card.longitude}`} target="_blank" rel="noreferrer">
                <MapPin size={14} /> Open emergency location
              </a>
            )}
            {card.is_mine && <button type="button" className="ws-secondary-btn ws-resolve-btn" onClick={async () => { await onResolve(card.id); load(); }}>Resolve emergency</button>}
          </article>
        ))}
      </div>
    </div>
  );
}

function EmergencyMessageTool({ location, contacts }) {
  const [situation, setSituation] = useState('I need help. Please contact me as soon as possible.');
  const [includeLocation, setIncludeLocation] = useState(true);
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);

  const prepare = () => {
    const text = buildEmergencyMessage(situation, includeLocation, location);
    setMessage(text);
    return text;
  };

  const broadcast = async () => {
    const text = prepare();
    setBusy(true);
    setStatus('');
    try {
      const card = await EmergencyCardService.publish({
        message: text,
        situation,
        includeLocation,
        latitude: location?.latitude,
        longitude: location?.longitude,
        expiresMinutes: 30,
      });
      setStatus('Emergency card is LIVE. Other signed-in WomenSafety users can now see it in their emergency network.');
      if (typeof navigator.share === 'function') {
        try {
          await navigator.share({ title: 'WomenSafety emergency card', text });
        } catch (err) {
          if (err?.name !== 'AbortError') await copyText(text);
        }
      } else {
        await copyText(text);
      }
      window.dispatchEvent(new CustomEvent('ws-emergency-card-published', { detail: card?.card }));
    } catch (err) {
      setStatus(err?.message || 'Could not publish the emergency card.');
    } finally {
      setBusy(false);
    }
  };

  const copy = async () => {
    const text = message || prepare();
    const ok = await copyText(text);
    setStatus(ok ? 'Emergency card text copied. Use Broadcast to make it visible to WomenSafety users.' : 'Clipboard access is blocked. Select the preview text and copy it manually.');
  };

  const openSms = () => {
    const text = message || prepare();
    window.location.href = `sms:?body=${encodeURIComponent(text)}`;
  };

  const resolve = async (id) => {
    try {
      await EmergencyCardService.resolve(id);
      setStatus('Your emergency card has been resolved and removed from the live network.');
    } catch (err) {
      setStatus(err?.message || 'Unable to resolve the emergency card.');
    }
  };

  return (
    <ToolModal title="Emergency Message Studio" eyebrow="LIVE • NETWORK BROADCAST" icon={MessageSquareText} onClose={() => window.dispatchEvent(new CustomEvent('ws-close-tool'))}>
      <p className="ws-modal-copy">Create a professional emergency card, optionally attach your current GPS position, and broadcast it to other signed-in WomenSafety users. Cards automatically expire after 30 minutes unless you resolve them.</p>
      <label className="ws-field-label">Emergency information</label>
      <textarea className="ws-tool-textarea" value={situation} onChange={(e) => { setSituation(e.target.value); setStatus(''); }} rows={4} />
      <label className="ws-check-row"><input type="checkbox" checked={includeLocation} onChange={(e) => setIncludeLocation(e.target.checked)} /><span>Attach current location when GPS is available</span></label>
      {contacts.length > 0 && <div className="ws-helper">{contacts.length} trusted contact{contacts.length > 1 ? 's are' : ' is'} already configured. The network broadcast does not modify them.</div>}
      {includeLocation && location?.latitude == null && <div className="ws-helper"><MapPin size={14} /> GPS is not currently available; the card will broadcast without coordinates.</div>}
      {message && <pre className="ws-message-preview">{message}</pre>}
      {status && <div className="ws-tool-status-success"><Check size={14} />{status}</div>}
      <div className="ws-modal-actions ws-modal-actions-wrap">
        <button type="button" className="ws-secondary-btn" onClick={prepare}>Preview</button>
        <button type="button" className="ws-secondary-btn" onClick={copy}><ClipboardCopy size={15} /> Copy Card</button>
        <button type="button" className="ws-secondary-btn" onClick={openSms}>Open SMS</button>
        <button type="button" className="ws-primary-btn" onClick={broadcast} disabled={busy}>{busy ? 'Broadcasting…' : 'Generate & Broadcast'}</button>
      </div>
      <CommunityEmergencyFeed onResolve={resolve} />
    </ToolModal>
  );
}


// Small pure-JS fallback so evidence verification still works if Web Crypto is unavailable.
function sha256Fallback(bytes) {
  const K = [
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2,
  ];
  const rotr = (x,n) => (x >>> n) | (x << (32-n));
  const bitLen = bytes.length * 8;
  const padded = new Uint8Array(((bytes.length + 9 + 63) >> 6) << 6);
  padded.set(bytes);
  padded[bytes.length] = 0x80;
  const view = new DataView(padded.buffer);
  view.setUint32(padded.length - 8, Math.floor(bitLen / 0x100000000), false);
  view.setUint32(padded.length - 4, bitLen >>> 0, false);

  let h0=0x6a09e667,h1=0xbb67ae85,h2=0x3c6ef372,h3=0xa54ff53a,h4=0x510e527f,h5=0x9b05688c,h6=0x1f83d9ab,h7=0x5be0cd19;
  const w = new Uint32Array(64);
  for (let offset=0; offset<padded.length; offset+=64) {
    for (let i=0;i<16;i++) w[i]=view.getUint32(offset+i*4,false);
    for (let i=16;i<64;i++) {
      const s0=rotr(w[i-15],7)^rotr(w[i-15],18)^(w[i-15]>>>3);
      const s1=rotr(w[i-2],17)^rotr(w[i-2],19)^(w[i-2]>>>10);
      w[i]=(w[i-16]+s0+w[i-7]+s1)>>>0;
    }
    let a=h0,b=h1,c=h2,d=h3,e=h4,f=h5,g=h6,h=h7;
    for (let i=0;i<64;i++) {
      const S1=rotr(e,6)^rotr(e,11)^rotr(e,25);
      const ch=(e&f)^((~e)&g);
      const temp1=(h+S1+ch+K[i]+w[i])>>>0;
      const S0=rotr(a,2)^rotr(a,13)^rotr(a,22);
      const maj=(a&b)^(a&c)^(b&c);
      const temp2=(S0+maj)>>>0;
      h=g;g=f;f=e;e=(d+temp1)>>>0;d=c;c=b;b=a;a=(temp1+temp2)>>>0;
    }
    h0=(h0+a)>>>0;h1=(h1+b)>>>0;h2=(h2+c)>>>0;h3=(h3+d)>>>0;h4=(h4+e)>>>0;h5=(h5+f)>>>0;h6=(h6+g)>>>0;h7=(h7+h)>>>0;
  }
  return [h0,h1,h2,h3,h4,h5,h6,h7].map((n)=>n.toString(16).padStart(8,'0')).join('');
}

async function calculateSha256(file) {
  const buffer = await file.arrayBuffer();
  if (globalThis.crypto?.subtle) {
    try {
      const digest = await globalThis.crypto.subtle.digest('SHA-256', buffer);
      return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
    } catch (_) {}
  }
  return sha256Fallback(new Uint8Array(buffer));
}

function EvidenceIntegrityTool() {
  const { user } = useAuth();
  const [file, setFile] = useState(null);
  const [hash, setHash] = useState('');
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const [hashes, setHashes] = useState([]);
  const [unlocked, setUnlocked] = useState(false);
  const [pin, setPin] = useState('');
  const [unlocking, setUnlocking] = useState(false);
  const [loadingHashes, setLoadingHashes] = useState(false);
  const inputRef = useRef(null);

  const loadHashes = async () => {
    setLoadingHashes(true);
    try {
      setHashes(await IntegrityService.getHashes());
    } catch (err) {
      setStatus(err?.message || 'Unable to load the saved hash vault.');
    } finally {
      setLoadingHashes(false);
    }
  };

  const unlock = async () => {
    setUnlocking(true);
    setStatus('');
    try {
      await IntegrityService.unlock(pin);
      setUnlocked(true);
      setPin('');
      await loadHashes();
      setStatus('Hash vault unlocked. Your saved fingerprints are now visible.');
    } catch (err) {
      setStatus(err?.message || 'Incorrect Emergency PIN.');
    } finally {
      setUnlocking(false);
    }
  };

  const calculate = async (selected) => {
    if (!selected) return;
    setFile(selected);
    setHash('');
    setStatus('');
    setBusy(true);
    try {
      const digest = await calculateSha256(selected);
      setHash(digest);
      await IntegrityService.saveHash({
        filename: selected.name,
        mimeType: selected.type || 'application/octet-stream',
        fileSizeBytes: selected.size,
        sha256: digest,
      });
      setStatus('SHA-256 fingerprint created and saved to your protected hash vault. The evidence file itself was not uploaded.');
      if (unlocked) await loadHashes();
    } catch (err) {
      setStatus(`Could not process or save this file: ${err?.message || 'browser/server error'}`);
    } finally {
      setBusy(false);
    }
  };

  const copy = async () => {
    if (!hash) return;
    setStatus((await copyText(hash)) ? 'SHA-256 fingerprint copied.' : 'Copy was blocked. Select the fingerprint and copy it manually.');
  };

  const reset = () => {
    setFile(null); setHash(''); setStatus('');
    if (inputRef.current) inputRef.current.value = '';
  };

  const deleteHash = async (id) => {
    try {
      await IntegrityService.deleteHash(id);
      setHashes((prev) => prev.filter((item) => item.id !== id));
      setStatus('Saved fingerprint removed from the vault.');
    } catch (err) {
      setStatus(err?.message || 'Unable to remove the saved fingerprint.');
    }
  };

  return (
    <ToolModal title="Evidence Integrity Check" eyebrow="PROTECTED • SHA-256 VAULT" icon={FileCheck2} onClose={() => window.dispatchEvent(new CustomEvent('ws-close-tool'))}>
      <p className="ws-modal-copy">Calculate a SHA-256 fingerprint locally, then save only the fingerprint and file metadata to your WomenSafety account. Your evidence file never leaves this browser.</p>
      <label className="ws-upload-zone">
        <FileText size={23} />
        <strong>{file ? file.name : 'Choose an evidence file'}</strong>
        <span>{file ? `${(file.size / 1024).toFixed(1)} KB selected • ${file.type || 'unknown type'}` : 'Click here to choose a file'}</span>
        <input ref={inputRef} type="file" className="ws-file-input" onChange={(e) => calculate(e.target.files?.[0])} />
      </label>
      {busy && <div className="ws-progress-note"><Gauge size={15} /> Reading file and calculating SHA-256…</div>}
      {status && !busy && <div className="ws-tool-status-success"><Check size={14} />{status}</div>}
      {hash && !busy && <div className="ws-hash-box"><span>SHA-256</span><code>{hash}</code><button type="button" onClick={copy} aria-label="Copy fingerprint"><ClipboardCopy size={15} /></button></div>}
      {file && !busy && <div className="ws-modal-actions"><button type="button" className="ws-secondary-btn" onClick={reset}>Choose another file</button></div>}

      <div className="ws-hash-vault">
        <div className="ws-hash-vault-head">
          <div><span className="ws-vault-lock"><Lock size={16} /></span><div><b>Saved Hash Vault</b><small>Protected with your Emergency PIN</small></div></div>
          {unlocked && <button type="button" className="ws-secondary-btn" onClick={() => setUnlocked(false)}><Lock size={14} /> Lock</button>}
        </div>
        {!unlocked ? (
          <div className="ws-vault-locked">
            <Lock size={26} />
            <strong>Your saved hashes are locked</strong>
            <span>Enter your 4-digit Emergency PIN to view the complete fingerprint history.</span>
            {!user?.hasEmergencyPin && <small>Set an Emergency PIN first in Settings → Security.</small>}
            <div className="ws-pin-row">
              <input inputMode="numeric" maxLength={4} type="password" value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))} placeholder="••••" aria-label="Emergency PIN" />
              <button type="button" className="ws-primary-btn" onClick={unlock} disabled={unlocking || pin.length !== 4}>{unlocking ? 'Unlocking…' : 'Unlock vault'}</button>
            </div>
          </div>
        ) : (
          <div className="ws-vault-open">
            <div className="ws-vault-open-head"><span><Unlock size={15} /> {hashes.length} saved fingerprint{hashes.length === 1 ? '' : 's'}</span><button type="button" className="ws-icon-btn" onClick={loadHashes} aria-label="Refresh saved hashes"><RefreshCw size={15} /></button></div>
            {loadingHashes && <div className="ws-community-empty">Loading saved fingerprints…</div>}
            {!loadingHashes && !hashes.length && <div className="ws-community-empty">No saved fingerprints yet. Choose a file above to create one.</div>}
            <div className="ws-hash-list">
              {hashes.map((item) => (
                <div className="ws-hash-row" key={item.id}>
                  <div className="ws-hash-row-main"><b>{item.filename}</b><small>{item.mime_type || 'file'} · {Math.max(0, Math.round(item.file_size_bytes / 1024))} KB · {new Date(item.created_at).toLocaleString()}</small><code>{item.sha256}</code></div>
                  <div className="ws-hash-row-actions"><button type="button" onClick={() => copyText(item.sha256)} aria-label="Copy saved hash"><ClipboardCopy size={14} /></button><button type="button" onClick={() => deleteHash(item.id)} aria-label="Delete saved hash"><Trash2 size={14} /></button></div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </ToolModal>
  );
}



function EmergencyDialer() {
  const numbers = [
    { number: '112', label: 'National emergency', note: 'Police, fire and medical emergency support' },
    { number: '181', label: 'Women Helpline', note: 'Women’s support and assistance' },
  ];
  return (
    <ToolModal title="Emergency Call Panel" eyebrow="NEW • DIRECT DIAL" icon={PhoneCall} onClose={() => window.dispatchEvent(new CustomEvent('ws-close-tool'))}>
      <p className="ws-modal-copy">Use the phone's dialer directly. These buttons use your device's <code>tel:</code> action; the browser does not place the call itself.</p>
      <div className="ws-dial-list">{numbers.map((item) => <a key={item.number} className="ws-dial-row" href={`tel:${item.number}`}><span><b>{item.number}</b><small>{item.label} · {item.note}</small></span><PhoneCall size={18} /></a>)}</div>
      <div className="ws-helper">112 is India's unified emergency number and 181 is the Women Helpline.</div>
    </ToolModal>
  );
}

export function ToolsPage() {
  const { location, contacts, setFakeCallOpen } = useSafety();
  const [modal, setModal] = useState(null);

  useEffect(() => {
    const close = () => setModal(null);
    window.addEventListener('ws-close-tool', close);
    return () => window.removeEventListener('ws-close-tool', close);
  }, []);

  const tools = useMemo(() => [
    { id: 'message', title: 'Emergency Message Studio', eyebrow: 'LIVE NETWORK', description: 'Create and broadcast an emergency card that active WomenSafety users can see in real time.', icon: MessageSquareText, tone: 'cyan', action: 'Open studio', onClick: () => setModal('message') },
    { id: 'integrity', title: 'Evidence Integrity Check', eyebrow: 'PROTECTED VAULT', description: 'Create SHA-256 fingerprints and keep every saved hash in a locked account vault.', icon: FileCheck2, tone: 'violet', action: 'Verify & save', onClick: () => setModal('integrity') },
    { id: 'fake-call', title: 'Fake Call', eyebrow: 'DISCREET EXIT', description: 'Trigger a simulated incoming call to create a discreet reason to leave an uncomfortable situation.', icon: PhoneCall, tone: 'blue', action: 'Start fake call', onClick: () => setFakeCallOpen(true) },
    { id: 'offline', title: 'Offline Safety Card', eyebrow: 'WORKS OFFLINE', description: 'Store a short emergency instruction locally so it remains available when connectivity is unreliable.', icon: LifeBuoy, tone: 'amber', action: 'Create card', onClick: () => setModal('offline') },
    { id: 'visual', title: 'Visual Help Signal', eyebrow: 'VISIBLE ALERT', description: 'Use a high-contrast on-screen signal when a visible alert is more useful than sound.', icon: Signal, tone: 'rose', action: 'Open signal', onClick: () => setModal('visual') },
    { id: 'dialer', title: 'Emergency Call Panel', eyebrow: 'DIRECT DIAL', description: 'Open your phone dialer for verified emergency support numbers.', icon: PhoneCall, tone: 'green', action: 'Open call panel', onClick: () => setModal('dialer') },
  ], []);

  return (
    <div className="ws-tools-v4 py-6 sm:py-8">
      <Container size="default">
        <section className="ws-tools-v4-hero">
          <div className="ws-tools-v4-kicker">WOMENSAFETY / NEW RESPONSE LAB</div>
          <div className="ws-tools-v4-title-row"><div><h1>Useful tools you can actually use.</h1><p>Emergency response, evidence verification, offline readiness and direct assistance — designed as connected tools instead of isolated demos.</p></div><div className="ws-tools-v4-counter"><Sparkles size={17}/><strong>6 connected tools</strong><span>built for response & preservation</span></div></div>
        </section>

        <div className="ws-tools-v4-status"><div><span className="ws-live-pip" />Tools are ready</div><span>{location.latitude !== null ? 'GPS available' : 'GPS will be requested only when needed'} · {contacts.length} trusted contact{contacts.length === 1 ? '' : 's'}</span></div>

        <div className="ws-tools-v4-grid">
          {tools.map((tool, index) => { const Icon = tool.icon; return <button key={tool.id} type="button" onClick={tool.onClick} className={`ws-tool-v4-card tone-${tool.tone} ${index === 0 ? 'existing' : 'new'}`}><div className="ws-tool-v4-top"><div className="ws-tool-v4-icon"><Icon size={22} /></div><span>{tool.eyebrow}</span></div><div><h3>{tool.title}</h3><p>{tool.description}</p></div><div className="ws-tool-v4-action">{tool.action}<ArrowUpRight size={15}/></div></button>; })}
        </div>

        <section className="ws-tools-v4-note"><div className="ws-note-icon"><ShieldAlert size={18}/></div><div><b>Live network + protected evidence vault.</b><span>Emergency cards are shared between signed-in WomenSafety users, while saved SHA-256 fingerprints stay behind the account's Emergency PIN. Embedded emergency sound has been removed from the Tools page.</span></div></section>
      </Container>

      {modal === 'message' && <EmergencyMessageTool location={location} contacts={contacts} />}
      {modal === 'integrity' && <EvidenceIntegrityTool />}
      {modal === 'offline' && <OfflineSafetyCardTool />}
      {modal === 'visual' && <VisualSignalTool />}
      {modal === 'dialer' && <EmergencyDialer />}
    </div>
  );
}
