import express from 'express';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.middleware.js';

const router = express.Router();

function cleanCard(row, includePrivate = false) {
  const expiresAt = row.expires_at ? new Date(row.expires_at) : null;
  const expired = expiresAt && expiresAt.getTime() <= Date.now();
  return {
    id: row.id,
    user_id: row.user_id,
    name: row.name || 'WomenSafety user',
    message: row.message,
    situation: row.situation || null,
    latitude: includePrivate && row.latitude != null ? Number(row.latitude) : null,
    longitude: includePrivate && row.longitude != null ? Number(row.longitude) : null,
    location_included: Boolean(row.location_included),
    status: expired ? 'expired' : row.status,
    expires_at: row.expires_at,
    created_at: row.created_at,
    is_mine: includePrivate ? Boolean(row.is_mine) : false,
  };
}

router.get('/feed', requireAuth, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT id, user_id, message, situation, latitude, longitude, location_included,
              status, expires_at, created_at
       FROM emergency_cards
       WHERE status = 'active'
       ORDER BY created_at DESC, id DESC
       LIMIT 50`
    );
    const active = rows.filter((r) => !r.expires_at || new Date(r.expires_at).getTime() > Date.now());
    const userIds = [...new Set(active.map((r) => Number(r.user_id)))];
    let users = [];
    if (userIds.length) {
      const [allUsers] = await pool.query(`SELECT id, name FROM users`);
      users = allUsers.filter((u) => userIds.includes(Number(u.id)));
    }
    const byId = new Map(users.map((u) => [Number(u.id), u.name]));
    return res.json({
      success: true,
      cards: active.map((r) => cleanCard({ ...r, name: byId.get(Number(r.user_id)) || 'WomenSafety user', is_mine: Number(r.user_id) === Number(req.user.id) }, Number(r.user_id) === Number(req.user.id))),
      count: active.length
    });
  } catch (err) {
    console.error('[Emergency Cards Feed Error]:', err);
    return res.status(500).json({ success: false, error: 'Unable to load the WomenSafety emergency network.' });
  }
});

router.post('/', requireAuth, async (req, res) => {
  try {
    const { message, situation, latitude, longitude, includeLocation, expiresMinutes } = req.body;
    const cleanMessage = typeof message === 'string' ? message.trim() : '';
    if (!cleanMessage) return res.status(400).json({ success: false, error: 'Emergency message is required.' });
    if (cleanMessage.length > 2000) return res.status(400).json({ success: false, error: 'Emergency message is too long.' });

    const useLocation = Boolean(includeLocation) && latitude != null && longitude != null;
    const lat = useLocation ? Number(latitude) : null;
    const lng = useLocation ? Number(longitude) : null;
    if (useLocation && (!Number.isFinite(lat) || lat < -90 || lat > 90 || !Number.isFinite(lng) || lng < -180 || lng > 180)) {
      return res.status(400).json({ success: false, error: 'Invalid emergency location.' });
    }

    const mins = Math.min(120, Math.max(5, Number(expiresMinutes) || 30));
    const expires = new Date(Date.now() + mins * 60 * 1000);

    // One active card per user keeps the network feed clean and prevents stale duplicates.
    await pool.query(`UPDATE emergency_cards SET status = 'resolved', updated_at = CURRENT_TIMESTAMP WHERE user_id = ? AND status = 'active'`, [req.user.id]);

    const [result] = await pool.query(
      `INSERT INTO emergency_cards
       (user_id, message, situation, latitude, longitude, location_included, status, expires_at)
       VALUES (?, ?, ?, ?, ?, ?, 'active', ?)`,
      [req.user.id, cleanMessage, typeof situation === 'string' ? situation.trim().slice(0, 1000) : null, lat, lng, useLocation ? 1 : 0, expires]
    );

    const [rows] = await pool.query(
      `SELECT id, user_id, message, situation, latitude, longitude, location_included,
              status, expires_at, created_at FROM emergency_cards WHERE id = ?`,
      [result.insertId]
    );
    return res.status(201).json({ success: true, card: cleanCard({ ...rows[0], name: req.user.name, is_mine: true }, true) });
  } catch (err) {
    console.error('[Create Emergency Card Error]:', err);
    return res.status(500).json({ success: false, error: 'Unable to publish the emergency card.' });
  }
});

router.post('/:id/resolve', requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [result] = await pool.query(
      `UPDATE emergency_cards SET status = 'resolved', updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ? AND status = 'active'`,
      [id, req.user.id]
    );
    if (!result.affectedRows) return res.status(404).json({ success: false, error: 'Active emergency card not found.' });
    return res.json({ success: true });
  } catch (err) {
    console.error('[Resolve Emergency Card Error]:', err);
    return res.status(500).json({ success: false, error: 'Unable to resolve the emergency card.' });
  }
});

export default router;
