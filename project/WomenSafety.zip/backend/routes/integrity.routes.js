import express from 'express';
import bcrypt from 'bcryptjs';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.middleware.js';

const router = express.Router();

router.post('/unlock', requireAuth, async (req, res) => {
  try {
    const pin = req.body?.pin != null ? String(req.body.pin).trim() : '';
    if (!/^\d{4}$/.test(pin)) return res.status(400).json({ success: false, error: 'Enter your 4-digit Emergency PIN.' });
    if (!req.user.emergency_pin) {
      return res.status(409).json({ success: false, error: 'Set an Emergency PIN in Settings before opening the protected hash vault.' });
    }
    const valid = await bcrypt.compare(pin, req.user.emergency_pin);
    if (!valid) return res.status(401).json({ success: false, error: 'Incorrect Emergency PIN.' });
    return res.json({ success: true, unlocked: true });
  } catch (err) {
    console.error('[Integrity Unlock Error]:', err);
    return res.status(500).json({ success: false, error: 'Unable to unlock the hash vault.' });
  }
});

router.get('/hashes', requireAuth, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT id, filename, mime_type, file_size_bytes, sha256, lock_enabled, created_at
       FROM integrity_hashes WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 200`,
      [req.user.id]
    );
    return res.json({
      success: true,
      hashes: rows.map((r) => ({
        id: r.id,
        filename: r.filename,
        mime_type: r.mime_type || '',
        file_size_bytes: Number(r.file_size_bytes || 0),
        sha256: r.sha256,
        lock_enabled: Boolean(r.lock_enabled),
        created_at: r.created_at,
      })),
    });
  } catch (err) {
    console.error('[Integrity Hash List Error]:', err);
    return res.status(500).json({ success: false, error: 'Unable to load saved hashes.' });
  }
});

router.post('/hashes', requireAuth, async (req, res) => {
  try {
    const { filename, mimeType, fileSizeBytes, sha256 } = req.body;
    const cleanName = typeof filename === 'string' ? filename.trim().slice(0, 255) : '';
    const cleanHash = typeof sha256 === 'string' ? sha256.trim().toLowerCase() : '';
    if (!cleanName) return res.status(400).json({ success: false, error: 'Filename is required.' });
    if (!/^[a-f0-9]{64}$/.test(cleanHash)) return res.status(400).json({ success: false, error: 'A valid SHA-256 hash is required.' });
    const size = Number(fileSizeBytes);
    const [result] = await pool.query(
      `INSERT INTO integrity_hashes (user_id, filename, mime_type, file_size_bytes, sha256, lock_enabled)
       VALUES (?, ?, ?, ?, ?, 1)`,
      [req.user.id, cleanName, typeof mimeType === 'string' ? mimeType.slice(0, 150) : null, Number.isFinite(size) ? size : 0, cleanHash]
    );
    return res.status(201).json({ success: true, id: result.insertId, message: 'Hash saved to your protected vault.' });
  } catch (err) {
    console.error('[Integrity Hash Save Error]:', err);
    return res.status(500).json({ success: false, error: 'Unable to save the hash.' });
  }
});

router.delete('/hashes/:id', requireAuth, async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM integrity_hashes WHERE id = ? AND user_id = ?', [Number(req.params.id), req.user.id]);
    return res.json({ success: true, deleted: Boolean(result.affectedRows) });
  } catch (err) {
    console.error('[Integrity Hash Delete Error]:', err);
    return res.status(500).json({ success: false, error: 'Unable to delete the saved hash.' });
  }
});

export default router;
