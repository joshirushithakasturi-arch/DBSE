# WomenSafety — Final Connected Safety Release

This build adds the requested production-style connected behavior to the existing WomenSafety project.

## Final changes

### 1. Emergency Message Studio → live WomenSafety emergency network
- Emergency Message Studio is now a real server-backed broadcast feature.
- **Generate & Broadcast** creates an active emergency card in the backend.
- Every authenticated WomenSafety user can see active emergency cards in the studio's **Live emergency cards** feed.
- The feed refreshes automatically every 10 seconds and has a manual refresh button.
- Cards show the broadcaster, emergency message, live status and expiry time.
- If GPS is available and the user enables location, the card includes the emergency location.
- Each user's active card is replaced when they publish a newer one.
- Cards automatically expire after 30 minutes.
- The owner can resolve their card immediately.
- The normal copy and SMS actions remain available.
- No audio is embedded in the Emergency Message Studio.

> Network visibility requires the WomenSafety backend and a signed-in account. It is not a localStorage-only demo.

### 2. Evidence Integrity Check → persistent protected hash vault
- SHA-256 is still calculated locally in the browser.
- The evidence file itself is **never uploaded** by the integrity tool.
- After calculation, the SHA-256 fingerprint and file metadata are saved to the authenticated user's backend account.
- The tool now includes **Saved Hash Vault**.
- Every saved fingerprint is shown with filename, file type, size and timestamp after unlocking.
- The vault is protected by the user's 4-digit Emergency PIN.
- Unlock, lock, refresh, copy and delete actions are included.
- If no Emergency PIN is configured, the UI directs the user to Settings → Security.

### 3. Emergency Sound tool removed
The old embedded Emergency Sound tool has been removed from the Tools page. The Tools page now focuses on connected emergency communication, evidence preservation, environment awareness, offline preparation, visual signaling and direct emergency calling.

### 4. Professional reliability additions
- Server-side validation for emergency cards and SHA-256 values.
- Automatic expiry for live emergency cards.
- Per-user ownership checks before resolving or deleting records.
- Persistent MySQL support with the existing JSON file-store fallback.
- New database tables are initialized automatically.
- Existing users, contacts, SOS, map, alerts and profile systems remain intact.

## New API endpoints

### Emergency cards
- `GET /api/emergency-cards/feed`
- `POST /api/emergency-cards`
- `POST /api/emergency-cards/:id/resolve`

### Integrity vault
- `POST /api/integrity/unlock`
- `GET /api/integrity/hashes`
- `POST /api/integrity/hashes`
- `DELETE /api/integrity/hashes/:id`

## Database

Two new tables are included:
- `emergency_cards`
- `integrity_hashes`

They are created automatically by backend initialization and are also included in `backend/schema.sql`.

## Run locally

From the project directory:

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:5157
```

Start the backend separately:

```bash
npm run backend
```

The frontend defaults to `/api`, so Vite's configured proxy/environment should point to the backend as in the existing project.

## Important security note

The final ZIP intentionally does not include a real `.env` file or exposed API credentials. Copy `.env.example` to `.env` and configure your own values.

Never commit production API keys or JWT secrets to source control.

## Emergency network behavior

To test the live-card feature with two accounts:

1. Start the backend.
2. Register/login as User A in one browser/profile.
3. Open Tools → Emergency Message Studio.
4. Press **Generate & Broadcast**.
5. Sign in as User B in another browser/profile.
6. Open Tools → Emergency Message Studio.
7. User A's active emergency card will appear in **Live emergency cards**.
8. User A can resolve it, or it will disappear automatically after expiry.

For the protected hash vault:

1. Configure an Emergency PIN in Settings → Security.
2. Open Tools → Evidence Integrity Check.
3. Select a file.
4. The SHA-256 fingerprint is calculated locally and saved automatically.
5. Open Saved Hash Vault and enter the Emergency PIN.
6. All saved fingerprints for that account are displayed.
